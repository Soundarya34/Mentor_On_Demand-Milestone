package com.demo.mentordemand.service;

import java.sql.SQLException;

import com.demo.mentordemand.model.Admin;

public interface AdminService {

	public boolean registerAdmin(Admin admin) throws SQLException;

	public Admin loginAdmin(String email, String password) throws SQLException;
}
