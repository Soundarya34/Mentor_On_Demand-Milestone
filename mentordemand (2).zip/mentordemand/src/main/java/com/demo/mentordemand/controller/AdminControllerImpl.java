package com.demo.mentordemand.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.mentordemand.dao.MentorDao;
import com.demo.mentordemand.model.Admin;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.model.RequestTraining;
import com.demo.mentordemand.service.AdminService;
import com.demo.mentordemand.service.MentorService;
import com.demo.mentordemand.service.SkillsService;

@Controller
public class AdminControllerImpl implements AdminController {

	@Autowired
	AdminService adminService;
	@Autowired
	SkillsService skillsService;
	@Autowired
	MentorService mentorService;
	@Autowired
	MentorDao mentorDao;

	@Override
	public boolean registerAdmin(Admin admin) throws SQLException {
		// TODO Auto-generated method stub
		return adminService.registerAdmin(admin);
	}

	@RequestMapping(path = "/registerAdminPage", method = RequestMethod.GET)
	public ModelAndView registerAdminPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerAdmin");
		model.addAttribute("registerAdmin", new Admin());
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}

	@RequestMapping(value = "/registerAdmin", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("registerAdmin") Admin registerAdmin, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			map.addAttribute("registerAdmin", registerAdmin);
			mav = new ModelAndView("registerAdmin");
			return mav;
		}

		else {
			map.addAttribute("registerAdmin", registerAdmin);
			adminService.registerAdmin(registerAdmin);
			mav = new ModelAndView("adminLogin");
			map.addAttribute("adminLogin", new Admin());
			return mav;
		}

	}

	@RequestMapping(path = "/adminLoginPage", method = RequestMethod.GET)
	public ModelAndView loginAdminPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminLogin");
		model.addAttribute("adminLogin", new Admin());
		return mv;
	}

	@RequestMapping(value = "/adminLogin", method = RequestMethod.POST)
	public ModelAndView adminLogin(@ModelAttribute("adminLogin") Admin adminLogin, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map, Model model) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("adminLogin", adminLogin);
		Admin check = adminService.loginAdmin(adminLogin.getEmail(), adminLogin.getPassword());
		if (check != null) {
			mav = new ModelAndView("adminLandingPage");
		}

		else {
			map.addAttribute("adminLogin", adminLogin);
			mav = new ModelAndView("adminLogin");
		}

		return mav;
	}

	@RequestMapping(path = "/adminPage", method = RequestMethod.GET)
	public ModelAndView adminPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminLandingPage");

		return mv;
	}

	@RequestMapping(path = "/viewMentors")
	public ModelAndView getMentorsList() throws SQLException {
		ModelAndView mv = new ModelAndView("viewMentors");
		mv.addObject("mentorDetails", mentorService.getMentorsList());

		return mv;
	}
	
	@RequestMapping(value = "/blockMentor", method = RequestMethod.GET)
	public ModelAndView blockMentor(@RequestParam("mentorId") int mentorId, Model model) throws Exception {

		Mentor mentor = mentorDao.findByMentorId(mentorId);
	mentor.setAccess(1);
		mentorDao.save(mentor);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminLandingPage");
		return mv;
	}
	
	@RequestMapping(value = "/unblockMentor", method = RequestMethod.GET)
	public ModelAndView unblockMentor(@RequestParam("mentorId") int mentorId, Model model) throws Exception {

		Mentor mentor = mentorDao.findByMentorId(mentorId);
	mentor.setAccess(0);
		mentorDao.save(mentor);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminLandingPage");
		return mv;
	}
	
	
	
	

}
