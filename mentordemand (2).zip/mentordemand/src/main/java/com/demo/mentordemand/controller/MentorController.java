package com.demo.mentordemand.controller;

import java.sql.SQLException;

import com.demo.mentordemand.model.Mentor;

public interface MentorController {

	public boolean registerMentor(Mentor mentor) throws SQLException;
}
