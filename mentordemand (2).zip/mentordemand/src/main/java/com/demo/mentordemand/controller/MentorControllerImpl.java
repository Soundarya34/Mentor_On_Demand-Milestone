package com.demo.mentordemand.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.demo.mentordemand.model.Skills;
import com.demo.mentordemand.model.User;
import com.demo.mentordemand.dao.MentorDao;
import com.demo.mentordemand.dao.RequestTrainingDao;
import com.demo.mentordemand.model.Admin;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.model.RequestTraining;
import com.demo.mentordemand.service.MentorService;
import com.demo.mentordemand.service.SkillsService;

@Controller
public class MentorControllerImpl implements MentorController {

	@Autowired
	MentorService mentorService;

	@Autowired
	SkillsService skillsService;

	@Autowired
	MentorDao mentorDao;

	@Autowired
	RequestTrainingDao reqTrainingDao;

	@Override
	public boolean registerMentor(Mentor mentor) throws SQLException {
		// TODO Auto-generated method stub
		return mentorService.registerMentor(mentor);
	}

	@RequestMapping(path = "/registerMentorPage", method = RequestMethod.GET)
	public ModelAndView registerAdminPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		List<Skills> skillsList;
		skillsList = skillsService.getSkillsList();
		mv.setViewName("registerMentor");
		model.addAttribute("registerMentor", new Mentor());
		model.addAttribute("skillsList", skillsList);
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}

	@RequestMapping(value = "/registerMentor", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("registerMentor") Mentor registerMentor, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			List<Skills> skillsList;
			skillsList = skillsService.getSkillsList();
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			map.addAttribute("registerMentor", registerMentor);
			map.addAttribute("skillsList", skillsList);
			mav = new ModelAndView("registerMentor");
			return mav;
		}

		else {
			registerMentor.setAccess(0);
			map.addAttribute("registerMentor", registerMentor);
			mentorService.registerMentor(registerMentor);
			mav = new ModelAndView("mentorLogin");
			map.addAttribute("mentorLogin", new Mentor());
			// if (registerUser.getUsertype().equalsIgnoreCase("Admin")) {
			// map.addAttribute("adminLogin", new User());
			// mav = new ModelAndView("adminLogin");
			// } else {
			// map.addAttribute("userLogin", new User());
			// mav = new ModelAndView("userLogin");
			// }

			return mav;
		}

	}

	@RequestMapping(path = "/mentorLoginPage", method = RequestMethod.GET)
	public ModelAndView loginMentorPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorLogin");
		model.addAttribute("mentorLogin", new Mentor());
		return mv;
	}

	@RequestMapping(value = "/mentorLogin", method = RequestMethod.POST)
	public ModelAndView adminLogin(@ModelAttribute("mentorLogin") Mentor mentorLogin, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map, Model model) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("mentorLogin", mentorLogin);
		Mentor check = mentorService.loginMentor(mentorLogin.getEmail(), mentorLogin.getPassword());
		session = request.getSession();
		int mentorId = mentorDao.findByMentorId(mentorLogin.getEmail());
		session.setAttribute("mentorId", mentorId);
		int access=mentorLogin.getAccess();
		System.out.println(access);
		if(access==0)
		{
		if (check != null) {
			mav = new ModelAndView("mentorLandingPage");

		}

		else {
			map.addAttribute("mentorLogin", mentorLogin);
			mav = new ModelAndView("mentorLogin");
		}
		}
		else
		{
			mav=new ModelAndView("HomePage");
			model.addAttribute("searchMentor", new Mentor());
			mav.addObject("skillsList", skillsService.getSkillsList());
			mav.addObject("message","No trainers found");
			mav.addObject("access","Your account is blocked");
		}
		return mav;
	}

	@RequestMapping(path = "/mentorNotifyPage", method = RequestMethod.GET)
	public String notifyPage(Model model) throws Exception {

		return "redirect:mentorNotifications";
	}

	@RequestMapping(value = "/mentorNotifications", method = RequestMethod.GET)
	public ModelAndView MentorNotificationPage(Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		int mentorId = (int) session.getAttribute("mentorId");

		List<RequestTraining> requestList = reqTrainingDao.findByMentorId(mentorId);
		ModelAndView mav = null;
		if (!requestList.isEmpty()) {
			mav = new ModelAndView("mentorNotifications");
			mav.addObject("requestList", requestList);
			model.addAttribute("searchMentor", new Mentor());
			mav.addObject("skillsList", skillsService.getSkillsList());
		} else {
			mav = new ModelAndView("mentorLandingPage");
			mav.addObject("message", "No notifications");
		}

		return mav;
	}

	@RequestMapping(value = "/approveStatus", method = RequestMethod.GET)
	public ModelAndView requestApproval(@RequestParam("trainingId") int trainingId, Model model) throws Exception {

		RequestTraining reqTraining = reqTrainingDao.findById(trainingId);
		reqTraining.setStatus("Approved");
		reqTrainingDao.save(reqTraining);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorLandingPage");
		return mv;
	}

	@RequestMapping(value = "/rejectStatus", method = RequestMethod.GET)
	public ModelAndView requestRejection(@RequestParam("trainingId") int trainingId, Model model) throws Exception {

		RequestTraining reqTraining = reqTrainingDao.findById(trainingId);
		reqTraining.setStatus("Rejected");
		reqTrainingDao.save(reqTraining);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorLandingPage");
		return mv;
	}

}
