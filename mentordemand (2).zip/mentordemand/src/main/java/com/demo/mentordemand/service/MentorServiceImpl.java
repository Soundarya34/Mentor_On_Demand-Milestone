package com.demo.mentordemand.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.demo.mentordemand.dao.MentorDao;
import com.demo.mentordemand.model.Mentor;

@Service
public class MentorServiceImpl implements MentorService{


	@Autowired
	 MentorDao mentorDao;
	
	@Override
	public boolean registerMentor(Mentor mentor) throws SQLException {
		// TODO Auto-generated method stub
		mentorDao.save(mentor);
		return true;
	}

	@Override
	public Mentor loginMentor(String email, String password) throws SQLException {
		// TODO Auto-generated method stub
		return mentorDao.loginMentor(email,password);
	}

	@Override
	public List<Mentor> findByTechnology(String mentorSkill) {
		// TODO Auto-generated method stub
		return mentorDao.findByTechnology(mentorSkill);
	}

	@Override
	public List<Mentor> getMentorsList() throws SQLException {
		// TODO Auto-generated method stub
		return mentorDao.findAll();
	}

}
