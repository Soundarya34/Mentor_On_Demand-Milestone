package com.demo.mentordemand.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.mentordemand.dao.RequestTrainingDao;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.model.RequestTraining;
import com.demo.mentordemand.model.Skills;
import com.demo.mentordemand.service.MentorService;
import com.demo.mentordemand.service.SkillsService;

@Controller
public class HomeControllerImpl implements HomeController {

	@Autowired
	SkillsService skillsService;

	@Autowired
	MentorService mentorService;
	
	@Autowired
	RequestTrainingDao reqTrainingDao;

	@RequestMapping(path = "/homePage", method = RequestMethod.GET)
	public ModelAndView homePage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("HomePage");
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}

	@RequestMapping(path = "/searchMentor", method = RequestMethod.POST)
	public ModelAndView searchMentorPage(@ModelAttribute("searchMentor") Mentor mentor, Model model,
			HttpServletRequest request, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		String mentorSkill = mentor.getTechnology();
		List<Mentor> check = mentorService.findByTechnology(mentorSkill);
		String username=(String) session.getAttribute("userName");
		List<RequestTraining> requestList= reqTrainingDao.findByUserName(username);
		if (!check.isEmpty()) {
			mv.setViewName("mentorList");
			mv.addObject("mentorList", check);
			mv.addObject("requestList", requestList);
			mv.addObject("skillsList", skillsService.getSkillsList());

		}
		else
		{
			mv.setViewName("HomePage");
			model.addAttribute("searchMentor", new Mentor());
			mv.addObject("skillsList", skillsService.getSkillsList());
			mv.addObject("message","No trainers found");
			
		}

		return mv;
	}

	
	@RequestMapping(path = "/searchInHome", method = RequestMethod.POST)
	public ModelAndView searchPage(@ModelAttribute("searchMentor") Mentor mentor, Model model,
			HttpServletRequest request, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		String mentorSkill = mentor.getTechnology();
		List<Mentor> check = mentorService.findByTechnology(mentorSkill);
		String username=(String) session.getAttribute("userName");
		List<RequestTraining> requestList= reqTrainingDao.findByUserName(username);
		if (!check.isEmpty()) {
			mv.setViewName("searchInHome");
			mv.addObject("mentorList", check);
			mv.addObject("requestList", requestList);
			mv.addObject("skillsList", skillsService.getSkillsList());

		}
		else
		{
			mv.setViewName("HomePage");
			model.addAttribute("searchMentor", new Mentor());
			mv.addObject("skillsList", skillsService.getSkillsList());
			mv.addObject("message","No trainers found");
			
		}

		return mv;
	}
	
	
	
	
	
	
	
	
	
	
}
