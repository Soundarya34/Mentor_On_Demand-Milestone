package com.demo.mentordemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.mentordemand.model.RequestTraining;

public interface RequestTrainingDao extends JpaRepository<RequestTraining, Integer>{

	@Query("Select req from RequestTraining req where req.mentorId =:mentorId")
	List<RequestTraining> findByMentorId(@Param("mentorId")int mentorId);

	@Query("Select req from RequestTraining req where req.trainingId =:trainingId")
	public RequestTraining findById(@Param("trainingId")int trainingId);

	@Query("Select req from RequestTraining req where req.userName =:userName")
	List<RequestTraining> findByUserName(@Param("userName")String userName);

	
	

}
