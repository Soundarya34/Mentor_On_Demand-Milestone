package com.demo.mentordemand.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.mentordemand.model.Skills;


public interface SkillsService {

	public boolean registerSkill(Skills skills) throws SQLException;

	public List<Skills> getSkillsList() throws SQLException;

}
